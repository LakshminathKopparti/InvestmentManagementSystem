<?php
$servername = "localhost";
$username = "root";
$password = "Lucky@24";
$dbname = "investment";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT u.name, u.email, SUM(i.amount) AS total_invested
        FROM users u
        JOIN investments i ON u.investor_id = i.investor_id
        GROUP BY u.investor_id
        ORDER BY total_invested DESC
        LIMIT 1";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h1>Top Investor</h1>";
    while ($row = $result->fetch_assoc()) {
        echo "Name: " . $row["name"] . "<br>Email: " . $row["email"] . "<br>Total Invested: $" . $row["total_invested"] . "<br>";
    }
} else {
    echo "No data found.";
}

$conn->close();
?>
