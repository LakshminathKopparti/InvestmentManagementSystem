<?php
$servername = "localhost";
$username = "root";
$password = "Lucky@24";
$dbname = "investment";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT i.asset_type, i.amount, u.name AS investor_name, i.purchase_date
        FROM investments i
        JOIN users u ON i.investor_id = u.investor_id
        ORDER BY i.amount DESC
        LIMIT 10";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h1>Top 10 Investments</h1>";
    while ($row = $result->fetch_assoc()) {
        echo "Investor: " . $row["investor_name"] . "<br>Asset Type: " . $row["asset_type"] . "<br>Amount: $" . $row["amount"] . "<br>Purchase Date: " . $row["purchase_date"] . "<br><br>";
    }
} else {
    echo "No data found.";
}

$conn->close();
?>
