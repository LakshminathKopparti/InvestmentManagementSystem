<?php
$servername = "localhost";
$username = "root";
$password = "Lucky@24";
$dbname = "investment";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT u.name, u.email, pp.net_gain_or_loss
        FROM users u
        JOIN portfolio_performance pp ON u.investor_id = pp.investor_id
        WHERE pp.net_gain_or_loss < 0";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h1>Underperforming Portfolios</h1>";
    while ($row = $result->fetch_assoc()) {
        echo "Name: " . $row["name"] . "<br>Email: " . $row["email"] . "<br>Net Loss: $" . $row["net_gain_or_loss"] . "<br><br>";
    }
} else {
    echo "No underperforming portfolios found.";
}

$conn->close();
?>
