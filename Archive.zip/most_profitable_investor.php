<?php
$servername = "localhost";
$username = "root";
$password = "Lucky@24";
$dbname = "investment";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT u.name, u.email, SUM(p.net_gain_or_loss) AS total_profit
        FROM users u
        JOIN portfolio_performance p ON u.investor_id = p.investor_id
        GROUP BY u.investor_id
        ORDER BY total_profit DESC
        LIMIT 1";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h1>Most Profitable Investor</h1>";
    while ($row = $result->fetch_assoc()) {
        echo "Name: " . $row["name"] . "<br>Email: " . $row["email"] . "<br>Total Profit: $" . $row["total_profit"] . "<br>";
    }
} else {
    echo "No data found.";
}

$conn->close();
?>
